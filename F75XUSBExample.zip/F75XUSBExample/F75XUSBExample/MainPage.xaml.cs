﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Threading.Tasks;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Core;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace F75XUSBExample
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
            this.Loaded += MainPage_Loaded;
        }

        F75XUSBDevice device = null; 
        private void MainPage_Loaded(object sender, RoutedEventArgs e)
        {
            device = new F75XUSBDevice(Device_SetupComplete);
            /*
            Random r = new Random();
            List<float> testFloats = new List<float>();
            for (int i = 0; i < 999; i +=1)
            {
                testFloats.Add(r.Next(1, 262000));
            }

            
            GraphMin.Text = testFloats.Min().ToString("#.##");
            GraphMax.Text = testFloats.Max().ToString("#.##");
            GraphSdDev.Text = testFloats.StdDev().ToString("#.##");
            GraphAverage.Text = testFloats.Average().ToString("#.##");
            */
        }

        private void Device_SetupComplete(object sender, EventArgs e)
        {
            device.GetVersion(); 

            Task.Run(() => this.Dispatcher.RunAsync(CoreDispatcherPriority.Normal, async () =>
            {
                MeasureButton.IsEnabled = true;
                /*
                LampOn.IsEnabled = true;
                LampOff.IsEnabled = true;
                ShutterOn.IsEnabled = true;
                ShutterOff.IsEnabled = true;
                */
                LampToggle.IsEnabled = true;
                ToggleShutter.IsEnabled = true;
            }));
        }

        Windows.UI.Xaml.Shapes.Path path1 = new Windows.UI.Xaml.Shapes.Path();
        List<float> Values = new List<float>();

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            MeasureButton.IsEnabled = false;
            device.TurnLampOn();
            device.OpenShutter();
            device.ReadSpectrometer(500, 10);

            Values.Clear();
            for (int i = 0; i < device.LastSpectrometerBytes.Length; i += 4)
            {
                Values.Add((float)BitConverter.ToUInt32(device.LastSpectrometerBytes, i));
                 
            }
            Debug.Write("\n");

            Task.Run(() => this.Dispatcher.RunAsync(CoreDispatcherPriority.Normal, async () =>
            {
                try
                {
                    DrawGraph();

                    GraphMin.Text = Values.Min().ToString("#.##");
                    GraphMax.Text = Values.Max().ToString("#.##");
                    GraphSdDev.Text = Values.StdDev().ToString("#.##");
                    GraphAverage.Text = Values.Average().ToString("#.##");

                }
                catch (Exception ec)
                {

                }
            }));

            device.CloseShutter();
            device.TurnLampOff();
            //while (true)
            //{
            //    device.GetVersion();
            //    device.ReadSpectrometer(8, 1000);
            //    device.GetData();
            //    for (int i = 0; i < device.LastSpectrometerBytes.Length; i += 4)
            //    {
            //        float f = BitConverter.ToSingle(device.LastSpectrometerBytes, i);
            //        Debug.Write(f + ",");
            //    }
            //    Debug.Write("\n");
            //}
            MeasureButton.IsEnabled = true;
        }

        private void DrawGraph()
        {
            if (Values.Count == 0) { return; }

            path1.Fill = new SolidColorBrush(Windows.UI.Colors.Blue);
            path1.Stroke = new SolidColorBrush(Windows.UI.Colors.Black);
            path1.StrokeThickness = 1;
            PathSegmentCollection myPathSegmentCollection = new PathSegmentCollection();
            int x = 0;
            float sum = Values.Max();
            double graphWidthCo = GraphCanvas.ActualWidth / Values.Count();
            double HeightPerUnit = GraphCanvas.ActualHeight / Values.Count();

            LineSegment myLineSegment = new LineSegment();
            myLineSegment.Point = new Point(0, GraphCanvas.ActualHeight);
            myPathSegmentCollection.Add(myLineSegment);

            foreach (float val in Values)
            {
                myLineSegment = new LineSegment();
                myLineSegment.Point = new Point(x * graphWidthCo, GraphCanvas.ActualHeight - (GraphCanvas.ActualHeight * (val / sum)));
                x++;
                myPathSegmentCollection.Add(myLineSegment);
            }

            myLineSegment = new LineSegment();
            myLineSegment.Point = new Point(GraphCanvas.ActualWidth, GraphCanvas.ActualHeight);
            myPathSegmentCollection.Add(myLineSegment);

            myLineSegment = new LineSegment();
            myLineSegment.Point = new Point(0, GraphCanvas.ActualHeight);
            myPathSegmentCollection.Add(myLineSegment);

            PathFigure figure = new PathFigure();
            figure.Segments = myPathSegmentCollection;
            PathFigureCollection myPathFigureCollection = new PathFigureCollection();
            myPathFigureCollection.Add(figure);
            PathGeometry myPathGeometry = new PathGeometry();
            myPathGeometry.Figures = myPathFigureCollection;
            path1.Data = myPathGeometry;
            if (!GraphCanvas.Children.Contains(path1))
            {
                GraphCanvas.Children.Insert(0, path1);
            }
        }
        /*
        private void LampOn_Click(object sender, RoutedEventArgs e)
        {
            device.TurnLampOn();
        }

        private void LampOff_Click(object sender, RoutedEventArgs e)
        {
            device.TurnLampOff();
        }

        private void ShutterOn_Click(object sender, RoutedEventArgs e)
        {
            device.OpenShutter();
        }

        private void ShutterOff_Click(object sender, RoutedEventArgs e)
        {
            device.CloseShutter();
        }
        */

        private void IntegrationTimeBox_Loaded(object sender, RoutedEventArgs e)
        {
            List<float> luii = new List<float>();

            float minTime = 100;
            float maxTime = 5000;
            float incSize = (maxTime - minTime) / 99;

            for(int i=0; i<100; i++)
            {
                luii.Add(minTime + (i * incSize));
            }

            IntegrationTimeBox.ItemsSource = luii;
        }

        private void ScansToAverageBox_Loaded(object sender, RoutedEventArgs e)
        {
            List<float> vals = new List<float>();

            float min = 1;
            float max = 100;
            float incSize = (max - min) / 99;

            for(int i=0; i<100; i++)
            {
                vals.Add(min + (i * incSize));
            }

            ScansToAverageBox.ItemsSource = vals;
        }

        private void GraphCanvas_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            DrawGraph();
        }

        private void LampToggle_Toggled(object sender, RoutedEventArgs e)
        {
            if(LampToggle.IsOn)
            {
                device.TurnLampOn();
            }
            else
            {
                device.TurnLampOff();
            }
        }

        private void ToggleShutter_Toggled(object sender, RoutedEventArgs e)
        {
            if(ToggleShutter.IsOn)
            {
                device.OpenShutter();
            }
            else
            {
                device.CloseShutter();
            }
        }
    }
}
