﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Windows.ApplicationModel.Core;
using Windows.Devices.Enumeration;
using Windows.Devices.Usb;
using Windows.Foundation;
using Windows.Security.Cryptography;
using Windows.Storage.Streams;
using Windows.UI.Core;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;

namespace F75XUSBExample
{
    class F75XUSBDevice
    {

        public UsbDevice USBDevice = null;


        public event EventHandler SetupComplete; 
        public F75XUSBDevice(EventHandler aSetupCompleteHandler)
        {

            SetupComplete += aSetupCompleteHandler;

            var setupRask = Task.Run(async () =>
            {
                DeviceInformationCollection dic = await Windows.Devices.Enumeration.DeviceInformation.FindAllAsync(
                                                        Windows.Devices.Usb.UsbDevice.GetDeviceSelector(0xDEAD, 0x0110),
                                                        null);

                if (dic.Count != 0)
                {
                    USBDevice = await Windows.Devices.Usb.UsbDevice.FromIdAsync(dic[0].Id);
                    SetupComplete?.Invoke(this, EventArgs.Empty);
                }

            });

        }

        public Version Version = new Version(0, 0, 0, 0);

        #region USB and protocol code

        public enum ProtocolCommand : byte
        {
            GetVersion = 0x86,
            RecordMeasurement = 0x89,
            GetData = 0x90,
            GetTimestamp = 0x91,
            TurnOnLamp = 0x92,
            TurnOffLamp = 0x93,
            OpenShutter = 0x94,
            CloseShutter = 0x95
        }

        public short getResponseSize(ProtocolCommand aCommand)
        {
            short result = 0;

            switch (aCommand)
            {
                case ProtocolCommand.GetData:
                    result = 1024;
                    break;

                case ProtocolCommand.RecordMeasurement:
                    result = 1024;
                    break;

                case ProtocolCommand.GetTimestamp:
                    result = 8;
                    break;

                case ProtocolCommand.GetVersion:
                    result = 8;
                    break;
                     
                default:
                    result = 0;
                    break;
            }

            return result;
        }

        private byte[] Execute(ProtocolCommand aCommand)
        {
            return Execute(aCommand, null);
        }

        private byte[] Execute(ProtocolCommand aCommand, byte[] aParameters)
        {
            Debug.WriteLine("Execute - Begin");
            byte[] command;

            if (USBDevice == null)
            {
                Debug.WriteLine("Execute - Quit");
                return null;
            }

            if (aParameters != null)
            {
                command = new byte[1 + aParameters.Length];
                Array.Copy(aParameters, 0, command, 1, aParameters.Length);
            }
            else
            {
                command = new byte[1];
            }

            command[0] = (byte)aCommand;

            IBuffer outputBuffer = CryptographicBuffer.CreateFromByteArray(command);

           // USBDevice.DefaultInterface.BulkInPipes[0].ClearStallAsync().AsTask().RunSynchronously();
           // USBDevice.DefaultInterface.BulkOutPipes[0].ClearStallAsync().AsTask().RunSynchronously();
            UsbBulkInPipe readPipe = USBDevice.DefaultInterface.BulkInPipes[0];
            UsbBulkOutPipe outPipe = USBDevice.DefaultInterface.BulkOutPipes[0];
            outPipe.WriteOptions |= UsbWriteOptions.ShortPacketTerminate;
            outPipe.WriteOptions |= UsbWriteOptions.AutoClearStall;

            readPipe.FlushBuffer();

            var stream = outPipe.OutputStream;
            DataWriter dw = new DataWriter(stream);
            dw.WriteBytes(command);

            var writeTask = Task.Run(async () =>
            {
                return await dw.StoreAsync();
            });
            uint x = writeTask.Result;

            byte[] response = new byte[getResponseSize(aCommand)];

            if (x == command.Length)
            {
                if (response.Length > 0)
                {

                   readPipe.ReadOptions |= UsbReadOptions.IgnoreShortPacket;
                    readPipe.ReadOptions |= UsbReadOptions.AutoClearStall;
                   readPipe.ReadOptions |= UsbReadOptions.AllowPartialReads;

                    var outStream = readPipe.InputStream;
                    DataReader reader = new DataReader(outStream);
                    
                    uint bytesRead = 0;

                    var readTask = Task.Run(async () =>
                    {
                        return await reader.LoadAsync((uint)response.Length);
                    });


                    bytesRead = readTask.Result;

                    if (bytesRead == response.Length)
                    {
                        reader.ReadBytes(response);
                    }
                    else
                    {
                        Debug.WriteLine("Got " + bytesRead + " bytes");
                    }
                }
            }


           // USBDevice.DefaultInterface.BulkInPipes[0].ClearStallAsync();
          //  USBDevice.DefaultInterface.BulkOutPipes[0].ClearStallAsync();
            Debug.WriteLine("Execute - Exit");
            return response;
        }

        #endregion

        #region Commands

        public byte[] LastSpectrometerBytes = new byte[0];

        public bool ReadSpectrometer(ushort aScansToAverage, ushort aIntegrationTime)
        {
            bool result = false;

            byte[] parameters = new byte[4];

            byte[] scansToAvgBytes = BitConverter.GetBytes(aScansToAverage);
            byte[] integrationTime = BitConverter.GetBytes(aIntegrationTime);

            parameters[0] = scansToAvgBytes[0];
            parameters[1] = scansToAvgBytes[1];

            parameters[2] = integrationTime[0];
            parameters[3] = integrationTime[1];

            LastSpectrometerBytes = Execute(ProtocolCommand.RecordMeasurement, parameters);
             
            result = true;

            return result;
        }

        public bool GetData()
        {
            bool result = false;
             
            LastSpectrometerBytes = Execute(ProtocolCommand.GetData);

            result = true;

            return result;
        }

        public bool GetVersion()
        {
            bool result = false;

            byte[] versionBytes = Execute(ProtocolCommand.GetVersion);

            ushort major = (ushort)BitConverter.ToInt16(versionBytes, 0);
            ushort minor = (ushort)BitConverter.ToInt16(versionBytes, 2);
            ushort build = (ushort)BitConverter.ToInt16(versionBytes, 4);
            ushort revision = (ushort)BitConverter.ToInt16(versionBytes, 6);

            result = true;

            return result;
        }

        public bool GetTimestamp()
        {
            bool result = false;

            byte[] timeStampBytes = Execute(ProtocolCommand.GetTimestamp);

            long timeStamp = BitConverter.ToInt64(timeStampBytes, 0);

            result = true;

            return result;
        }


        public bool OpenShutter()
        {
            bool result = false;

            byte[] data = Execute(ProtocolCommand.OpenShutter);
             
            result = true;

            return result;
        }

        public bool CloseShutter()
        {
            bool result = false;

            byte[] data = Execute(ProtocolCommand.CloseShutter);

            result = true;

            return result;
        }

        public bool TurnLampOn()
        {
            bool result = false;

            byte[] data = Execute(ProtocolCommand.TurnOnLamp);

            result = true;

            return result;
        }
        #endregion
        public bool TurnLampOff()
        {
            bool result = false;

            byte[] data = Execute(ProtocolCommand.TurnOffLamp);

            result = true;

            return result;
        }

    }
}
